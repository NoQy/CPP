$(document).ready(function () {
  $("#btnNavbarToggler").click(() => {
    $("#menu1").toggle(200);
  });

  window.onscroll = () => {
    $("#menu1").slideUp(300);
  };

  // We use slider in another file couse we need it only in home page not other page.
  //   $(".slider1").slick({
  //     dots: true,
  //     infinity: true,
  //     speed: 500,
  //     slidesToShow: 1,
  //     slidesToScroll: 1,
  //     autoplay: true,
  //     autoplaySpeed: 3000,
  //     mobileFirst: true,
  //     pauseOnHover: false,
  //   });
});

// This listener count the gaving numbers.
document.addEventListener("DOMContentLoaded", () => {
  function counter(id, start, end, duration) {
    let obj = document.getElementById(id),
      cur = start,
      range = end - start,
      inc = end > start ? 1 : -1,
      step = Math.abs(Math.floor(duration / range)),
      timer = setInterval(() => {
        cur += inc;
        obj.textContent = cur;
        if (cur == end) {
          clearInterval(timer);
        }
      }, step);
  }

  counter("cnt1", 0, 1500, 100);
  counter("cnt2", 10, 540, 3000);
  counter("cnt3", 210, 800, 3500);
  counter("cnt4", 0, 6, 7000);
});
