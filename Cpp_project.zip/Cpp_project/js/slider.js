$(document).ready(function () {
  $(".slider1").slick({
    dots: true,
    infinity: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    mobileFirst: true,
    pauseOnHover: false,
  });
});
